CLOSED NETWORK — START HERE
===========================

Needs on the target machine: python3 (+ git if you sync progress to GitHub).
Does NOT need: pip, internet, venv, sudo, Docker.

1) tar -xzf pi-sdr-academy.tar.gz
2) cd pi-sdr-academy
3) ./run.sh
4) Open the URL it prints (usually http://127.0.0.1:8080/)

Student loop: Start → solve in ./challenge → Done

Instructor / management:
  ACADEMY_ADMIN=1 ./run.sh
  Open /admin  — users, add/remove challenges, progress sync
  First run creates academy-progress.git; each user’s progress/<id>
  branch auto-updates on every solve. Read MANAGE.txt for details.
