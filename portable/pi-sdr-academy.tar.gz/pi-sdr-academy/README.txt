CLOSED NETWORK — START HERE
===========================

Needs on the target machine: python3 only.
Does NOT need: pip, internet, venv, sudo, Docker.

1) tar -xzf pi-sdr-academy.tar.gz
2) cd pi-sdr-academy
3) ./run.sh
4) Open the URL it prints (usually http://127.0.0.1:8080/)

Then: Start → solve in ./challenge → Done

That's the whole install.
